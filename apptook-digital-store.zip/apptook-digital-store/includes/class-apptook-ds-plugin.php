<?php
/**
 * Main plugin controller.
 *
 * @package Apptook_Digital_Store
 */

declare(strict_types=1);

if (! defined('ABSPATH')) {
	exit;
}

final class Apptook_DS_Plugin {

	private static ?self $instance = null;

	public static function instance(): self {
		if (self::$instance === null) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action('init', array(Apptook_DS_Post_Types::class, 'register_post_types'));
		add_action('plugins_loaded', array($this, 'load_textdomain'));
		Apptook_DS_Admin::instance();
		Apptook_DS_Ajax::instance();
		Apptook_DS_Public::instance();
	}

	public function load_textdomain(): void {
		load_plugin_textdomain(
			'apptook-digital-store',
			false,
			dirname(plugin_basename(APPTOOK_DS_FILE)) . '/languages'
		);
	}
}
