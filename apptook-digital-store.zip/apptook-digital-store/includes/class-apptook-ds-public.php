<?php
/**
 * Front-end: shortcodes, assets, template.
 *
 * @package Apptook_Digital_Store
 */

declare(strict_types=1);

if (! defined('ABSPATH')) {
	exit;
}

final class Apptook_DS_Public {

	private static ?self $instance = null;

	public static function instance(): self {
		if (self::$instance === null) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_shortcode('apptook_shop', array($this, 'shortcode_shop'));
		add_shortcode('apptook_library', array($this, 'shortcode_library'));
		add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));
		add_filter('single_template', array($this, 'single_product_template'));
	}

	public function single_product_template(string $template): string {
		if (is_singular('apptook_product')) {
			$plugin_template = APPTOOK_DS_PATH . 'templates/single-apptook_product.php';
			if (is_readable($plugin_template)) {
				return $plugin_template;
			}
		}
		return $template;
	}

	private function should_load_assets(): bool {
		if (is_singular('apptook_product')) {
			return true;
		}
		global $post;
		if ($post instanceof WP_Post && has_shortcode($post->post_content, 'apptook_library')) {
			return true;
		}
		return false;
	}

	public function enqueue_assets(): void {
		if (! $this->should_load_assets()) {
			return;
		}

		wp_enqueue_style(
			'apptook-ds-frontend',
			APPTOOK_DS_URL . 'assets/css/frontend.css',
			array(),
			APPTOOK_DS_VERSION
		);

		wp_enqueue_script(
			'apptook-ds-frontend',
			APPTOOK_DS_URL . 'assets/js/frontend.js',
			array(),
			APPTOOK_DS_VERSION,
			true
		);

		wp_localize_script(
			'apptook-ds-frontend',
			'apptookDS',
			array(
				'ajaxUrl' => admin_url('admin-ajax.php'),
				'nonce'   => wp_create_nonce('apptook_ds_public'),
				'i18n'    => array(
					'loginRequired' => __('กรุณาเข้าสู่ระบบก่อนซื้อ', 'apptook-digital-store'),
					'uploading'     => __('กำลังอัปโหลด...', 'apptook-digital-store'),
					'error'         => __('เกิดข้อผิดพลาด ลองใหม่อีกครั้ง', 'apptook-digital-store'),
					'next'          => __('ดำเนินการต่อ — อัปโหลดสลิป', 'apptook-digital-store'),
					'payTitle'      => __('ชำระด้วยพร้อมเพย์', 'apptook-digital-store'),
					'slipTitle'     => __('อัปโหลดสลิปการโอน', 'apptook-digital-store'),
					'confirmSlip'   => __('ส่งสลิป', 'apptook-digital-store'),
					'close'         => __('ปิด', 'apptook-digital-store'),
				),
			)
		);
	}

	public function shortcode_shop(): string {
		$q = new WP_Query(
			array(
				'post_type'      => 'apptook_product',
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'orderby'        => 'date',
				'order'          => 'DESC',
			)
		);

		ob_start();
		?>
		<div class="apptook-ds apptook-ds-shop">
			<?php
			if (! $q->have_posts()) {
				echo '<p class="apptook-ds-empty">' . esc_html__('ยังไม่มีสินค้า', 'apptook-digital-store') . '</p>';
			} else {
				echo '<ul class="apptook-ds-shop-list">';
				while ($q->have_posts()) {
					$q->the_post();
					$pid   = get_the_ID();
					$price = get_post_meta($pid, '_apptook_price', true);
					?>
					<li class="apptook-ds-shop-item">
						<a class="apptook-ds-shop-link" href="<?php echo esc_url(get_permalink()); ?>">
							<?php if (has_post_thumbnail()) : ?>
								<span class="apptook-ds-shop-thumb"><?php the_post_thumbnail('medium'); ?></span>
							<?php endif; ?>
							<span class="apptook-ds-shop-title"><?php the_title(); ?></span>
							<span class="apptook-ds-shop-price"><?php echo esc_html((string) $price); ?> <?php esc_html_e('บาท', 'apptook-digital-store'); ?></span>
						</a>
					</li>
					<?php
				}
				echo '</ul>';
				wp_reset_postdata();
			}
			?>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	public function shortcode_library(): string {
		if (! is_user_logged_in()) {
			return '<p class="apptook-ds apptook-ds-notice">' . esc_html__('กรุณาเข้าสู่ระบบเพื่อดูคลังของคุณ', 'apptook-digital-store') . '</p>';
		}

		$user_id = get_current_user_id();
		$orders = new WP_Query(
			array(
				'post_type'        => 'apptook_order',
				'post_status'      => 'publish',
				'posts_per_page'   => 50,
				'suppress_filters' => true,
				'meta_query'       => array(
					'relation' => 'AND',
					array(
						'key'   => '_apptook_customer_id',
						'value' => $user_id,
					),
					array(
						'key'   => '_apptook_status',
						'value' => Apptook_DS_Post_Types::ORDER_PAID,
					),
				),
				'orderby'          => 'date',
				'order'            => 'DESC',
			)
		);

		ob_start();
		?>
		<div class="apptook-ds apptook-ds-library">
			<?php
			if (! $orders->have_posts()) {
				echo '<p class="apptook-ds-empty">' . esc_html__('ยังไม่มีสินค้าที่ชำระแล้ว', 'apptook-digital-store') . '</p>';
			} else {
				echo '<ul class="apptook-ds-library-list">';
				while ($orders->have_posts()) {
					$orders->the_post();
					$oid        = get_the_ID();
					$product_id = (int) get_post_meta($oid, '_apptook_product_id', true);
					$key        = get_post_meta($oid, '_apptook_license_key', true);
					?>
					<li class="apptook-ds-library-item">
						<h3 class="apptook-ds-library-title"><?php echo esc_html(get_the_title($product_id)); ?></h3>
						<p class="apptook-ds-library-key">
							<span class="apptook-ds-library-key-label"><?php esc_html_e('คีย์ / ไลเซนส์', 'apptook-digital-store'); ?></span>
							<code class="apptook-ds-key-value"><?php echo esc_html((string) $key); ?></code>
						</p>
					</li>
					<?php
				}
				echo '</ul>';
				wp_reset_postdata();
			}
			?>
		</div>
		<?php
		return (string) ob_get_clean();
	}
}
